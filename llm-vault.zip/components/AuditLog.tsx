import React from 'react';
import { AuditLogEntry, SafetyStatus } from '../types';

interface Props {
  logs: AuditLogEntry[];
}

export const AuditLog: React.FC<Props> = ({ logs }) => {
  const downloadLogs = () => {
    const content = JSON.stringify(logs, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `llm-vault-audit-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center mb-4">
        <div>
           <h2 className="text-xl font-bold flex items-center gap-2">
             <i className="fas fa-list-alt text-indigo-400"></i> Provenance Ledger
           </h2>
           <p className="text-slate-400 text-xs mt-1">Immutable audit trail for all system interactions.</p>
        </div>
        <button 
          onClick={downloadLogs}
          className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-2 rounded border border-slate-700 transition-colors"
        >
          <i className="fas fa-download mr-1"></i> Export JSON
        </button>
      </div>

      <div className="bg-slate-800/50 rounded-xl border border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-900 text-slate-400 uppercase font-mono text-xs">
              <tr>
                <th className="px-6 py-3">Timestamp</th>
                <th className="px-6 py-3">Module</th>
                <th className="px-6 py-3">Action</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Hash</th>
                <th className="px-6 py-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-slate-500 italic">No activity recorded yet.</td>
                </tr>
              ) : (
                logs.slice().reverse().map((log) => (
                  <tr key={log.id} className="hover:bg-slate-700/30 transition-colors">
                    <td className="px-6 py-3 font-mono text-xs text-slate-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase
                        ${log.module === 'Input' ? 'bg-blue-500/20 text-blue-400' : 
                          log.module === 'Output' ? 'bg-purple-500/20 text-purple-400' :
                          log.module === 'File' ? 'bg-orange-500/20 text-orange-400' : 
                          'bg-slate-500/20 text-slate-400'}`}>
                        {log.module}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-slate-200">{log.action}</td>
                    <td className="px-6 py-3">
                      <span className={`flex items-center gap-1.5 font-medium
                        ${log.status === SafetyStatus.SAFE ? 'text-emerald-400' : 
                          log.status === SafetyStatus.WARNING ? 'text-amber-400' : 'text-rose-400'}`}>
                        <i className={`fas ${log.status === SafetyStatus.SAFE ? 'fa-check' : 'fa-exclamation-circle'}`}></i>
                        {log.status === SafetyStatus.SAFE ? 'Allowed' : 'Blocked'}
                      </span>
                    </td>
                    <td className="px-6 py-3 font-mono text-xs text-slate-500 truncate max-w-[100px]" title={log.hash}>
                      {log.hash || '-'}
                    </td>
                    <td className="px-6 py-3 text-slate-400 truncate max-w-[200px]" title={log.details}>
                      {log.details}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
