import React, { useState } from 'react';
import { scanOutput } from '../services/geminiService';
import { OutputScanResult, AuditLogEntry, SafetyStatus } from '../types';

interface Props {
  addAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

export const OutputGuard: React.FC<Props> = ({ addAuditLog }) => {
  const [output, setOutput] = useState('');
  const [result, setResult] = useState<OutputScanResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleScan = async () => {
    if (!output.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await scanOutput(output);
      setResult(res);
      addAuditLog({
        module: 'Output',
        action: 'Scan Model Output',
        status: res.safe ? SafetyStatus.SAFE : SafetyStatus.DANGER,
        details: res.safe ? 'Content Safe' : res.reason,
        hash: 'N/A'
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <i className="fas fa-lock text-indigo-400"></i> Output-Side Guardrails
        </h2>
        <p className="text-slate-400 text-sm mb-4">
          Blocks PII, Malware signatures, and Toxic content before it reaches the user.
        </p>

        <div className="relative">
          <textarea
            value={output}
            onChange={(e) => setOutput(e.target.value)}
            className="w-full h-32 bg-slate-900 border border-slate-700 rounded-lg p-4 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono text-sm"
            placeholder="Paste simulated LLM response here..."
          />
        </div>

        <button
          onClick={handleScan}
          disabled={loading || !output}
          className={`mt-4 w-full py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all ${
            loading ? 'bg-slate-700 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-900/20'
          }`}
        >
          {loading ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-microscope"></i>}
          Scan Output
        </button>
      </div>

      {result && (
        <div className={`p-6 rounded-xl border ${result.safe ? 'bg-emerald-950/30 border-emerald-500/30' : 'bg-rose-950/30 border-rose-500/30'} backdrop-blur-sm animate-fade-in-up`}>
           <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${result.safe ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                <i className={`fas ${result.safe ? 'fa-check-circle' : 'fa-times-circle'} text-2xl`}></i>
              </div>
              <div className="flex-1">
                <h3 className={`text-lg font-bold mb-1 ${result.safe ? 'text-emerald-300' : 'text-rose-300'}`}>
                  {result.safe ? 'Response Approved' : 'Response Intercepted'}
                </h3>
                <p className="text-slate-300 text-sm mb-3">{result.reason}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                   <div className="bg-black/20 p-2 rounded">
                      <span className="text-slate-500 block">PII Detected</span>
                      <span className="font-mono text-slate-200">{result.pii_detected.length > 0 ? result.pii_detected.join(', ') : 'None'}</span>
                   </div>
                   <div className="bg-black/20 p-2 rounded">
                      <span className="text-slate-500 block">Malware Signature</span>
                      <span className="font-mono text-slate-200">{result.malware_detected ? 'DETECTED' : 'Clean'}</span>
                   </div>
                   <div className="bg-black/20 p-2 rounded col-span-2">
                       <span className="text-slate-500 block">Toxicity Score</span>
                       <div className="w-full bg-slate-700 rounded-full h-1.5 mt-1">
                          <div className={`h-1.5 rounded-full ${result.toxicity_score > 0.7 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{width: `${result.toxicity_score * 100}%`}}></div>
                       </div>
                   </div>
                </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
