import React from 'react';
import { FileAnalysisResult } from '../types';

interface FileCardProps {
  result: FileAnalysisResult;
}

export const FileCard: React.FC<FileCardProps> = ({ result }) => {
  let bgColor = "bg-emerald-950/40";
  let borderColor = "border-emerald-500/30";
  let icon = "fa-shield-check";
  let iconColor = "text-emerald-400";
  let statusText = "Clean";

  if (result.poisoned) {
    bgColor = "bg-rose-950/40";
    borderColor = "border-rose-500/30";
    icon = "fa-biohazard";
    iconColor = "text-rose-400";
    statusText = "Poisoned";
  } else if (!result.poisoned && result.confidence < 0.8 && result.technique !== 'clean') {
    bgColor = "bg-amber-950/40";
    borderColor = "border-amber-500/30";
    icon = "fa-exclamation-triangle";
    iconColor = "text-amber-400";
    statusText = "Suspicious";
  }

  return (
    <div className={`rounded-xl border ${borderColor} ${bgColor} backdrop-blur-md shadow-lg overflow-hidden transition-all duration-300 animate-fade-in group hover:shadow-2xl`}>
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
             <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconColor} bg-white/5`}>
               <i className={`fas ${icon} text-xl`}></i>
             </div>
             <div>
               <h3 className="font-bold text-slate-100 truncate max-w-[200px]" title={result.fileName}>{result.fileName}</h3>
               <p className="text-xs text-slate-400 font-mono">{result.fileType || 'Unknown Type'} • {(result.fileSize / 1024).toFixed(1)} KB</p>
             </div>
          </div>
          <div className={`px-3 py-1 rounded-full border text-xs font-bold uppercase tracking-wider ${borderColor} ${iconColor} bg-black/20`}>
            {statusText}
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs">
             <div className="bg-black/20 p-2 rounded border border-white/5">
                <span className="text-slate-500 block mb-1">Technique</span>
                <span className="text-slate-200 font-medium capitalize">{result.technique.replace('_', ' ')}</span>
             </div>
             <div className="bg-black/20 p-2 rounded border border-white/5">
                <span className="text-slate-500 block mb-1">Confidence</span>
                <span className="text-slate-200 font-medium">{(result.confidence * 100).toFixed(0)}%</span>
             </div>
          </div>
          
          <div className="bg-black/20 p-3 rounded border border-white/5">
            <p className="text-sm text-slate-300 leading-relaxed">
              <span className="text-slate-500 font-semibold mr-2">Analysis:</span>
              {result.reason}
            </p>
          </div>

          <div>
             <span className="text-xs text-slate-500 uppercase font-semibold mb-1 block">Sanitized Snippet</span>
             <div className="bg-slate-950/60 p-2 rounded border border-slate-800 font-mono text-xs text-slate-400 overflow-hidden text-ellipsis whitespace-nowrap">
                {result.sanitizedSnippet}
             </div>
          </div>

          <div>
             <span className="text-xs text-slate-500 uppercase font-semibold mb-1 block">SHA-256 Hash</span>
             <div className="bg-slate-950/60 p-2 rounded border border-slate-800 font-mono text-[10px] text-slate-500 break-all select-all hover:text-slate-300 transition-colors cursor-pointer" title="Click to copy" onClick={() => navigator.clipboard.writeText(result.hash)}>
                {result.hash}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
