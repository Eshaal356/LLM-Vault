import React, { useState } from 'react';
import { AuditLogEntry, SafetyStatus } from '../types';

interface Props {
  addAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

export const ModelHardening: React.FC<Props> = ({ addAuditLog }) => {
  const [isRedTeaming, setIsRedTeaming] = useState(false);
  const [redTeamResults, setRedTeamResults] = useState<string[]>([]);
  const [watermarking, setWatermarking] = useState(true);
  const [sandboxMode, setSandboxMode] = useState(true);

  const runRedTeam = async () => {
    setIsRedTeaming(true);
    setRedTeamResults([]);
    
    const attacks = [
      "Attempting DAN 14.0 Jailbreak...",
      "Injecting Base64 Obfuscated Payload...",
      "Testing Roleplay Context Switch...",
      "Probing PII Leakage via Completion...",
      "Stress Testing Token Limit (DoS)..."
    ];

    addAuditLog({
        module: 'Model',
        action: 'Red Team Test Started',
        status: SafetyStatus.WARNING,
        details: 'Automated adversarial testing suite initiated.',
        hash: 'TEST_SUITE_A'
    });

    for (const attack of attacks) {
      await new Promise(r => setTimeout(r, 800)); // Simulate work
      setRedTeamResults(prev => [...prev, attack]);
    }
    
    addAuditLog({
        module: 'Model',
        action: 'Red Team Test Completed',
        status: SafetyStatus.SAFE,
        details: 'All 5 attack vectors neutralized by defensive layers.',
        hash: 'TEST_SUITE_A_RESULTS'
    });

    setIsRedTeaming(false);
  };

  const toggleWatermark = () => {
      const newState = !watermarking;
      setWatermarking(newState);
      addAuditLog({
          module: 'Model',
          action: 'Config Change',
          status: SafetyStatus.WARNING,
          details: `Output Watermarking ${newState ? 'Enabled' : 'Disabled'}`,
          hash: 'CONFIG_WM'
      });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
             <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                 <i className="fas fa-cogs text-indigo-400"></i> Model Configuration
             </h3>
             <div className="space-y-4">
                 <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg">
                     <div>
                         <div className="text-sm font-semibold text-slate-200">Sandbox Execution</div>
                         <div className="text-xs text-slate-500">Isolate unsafe code interpretation</div>
                     </div>
                     <button onClick={() => setSandboxMode(!sandboxMode)} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${sandboxMode ? 'bg-emerald-600' : 'bg-slate-600'}`}>
                         <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${sandboxMode ? 'translate-x-6' : 'translate-x-1'}`} />
                     </button>
                 </div>
                 <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg">
                     <div>
                         <div className="text-sm font-semibold text-slate-200">Invisible Watermarking</div>
                         <div className="text-xs text-slate-500">Fingerprint generated text</div>
                     </div>
                     <button onClick={toggleWatermark} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${watermarking ? 'bg-emerald-600' : 'bg-slate-600'}`}>
                         <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${watermarking ? 'translate-x-6' : 'translate-x-1'}`} />
                     </button>
                 </div>
                 <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg">
                     <div>
                         <div className="text-sm font-semibold text-slate-200">Adversarial Defense</div>
                         <div className="text-xs text-slate-500">Input perturbation smoothing</div>
                     </div>
                     <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded">ACTIVE</span>
                 </div>
             </div>
          </div>

          <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-10">
                 <i className="fas fa-dragon text-9xl"></i>
             </div>
             <h3 className="font-bold text-white mb-2 flex items-center gap-2 relative z-10">
                 <i className="fas fa-meteor text-rose-400"></i> Automated Red Teaming
             </h3>
             <p className="text-sm text-slate-400 mb-6 relative z-10">
                 Simulate advanced attack vectors against the model to validate defense efficacy.
             </p>
             <button 
               onClick={runRedTeam}
               disabled={isRedTeaming}
               className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 relative z-10 transition-all ${isRedTeaming ? 'bg-slate-700 text-slate-400' : 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-900/20'}`}
             >
                 {isRedTeaming ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-play"></i>}
                 {isRedTeaming ? 'Running Attack Suite...' : 'Start Red Team Attack'}
             </button>
          </div>
      </div>

      {/* Terminal Output */}
      <div className="bg-black/80 rounded-xl border border-slate-700 p-4 font-mono text-xs h-64 overflow-y-auto">
          <div className="text-slate-500 mb-2 border-b border-slate-800 pb-2">
              <i className="fas fa-terminal mr-2"></i>Security Console
          </div>
          <div className="space-y-1">
              <div className="text-emerald-500">root@llm-vault:~# systemctl status defenses</div>
              <div className="text-slate-300">● defenses.service - LLM Adversarial Shield</div>
              <div className="text-slate-300">&nbsp;&nbsp;Loaded: loaded (/etc/systemd/system/defenses.service; enabled)</div>
              <div className="text-slate-300">&nbsp;&nbsp;Active: <span className="text-emerald-400 font-bold">active (running)</span> since {new Date().toLocaleDateString()}</div>
              {redTeamResults.map((line, i) => (
                  <div key={i} className="mt-2 animate-fade-in">
                      <div className="text-amber-400">root@llm-vault:~# ./red-team-suite --target=gemini-2.5</div>
                      <div className="text-slate-300">&gt; {line}</div>
                      <div className="text-emerald-500">&gt; Blocked by InputFirewall [Confidence: 0.99]</div>
                  </div>
              ))}
              {isRedTeaming && (
                   <div className="mt-2 text-slate-400 animate-pulse">_</div>
              )}
          </div>
      </div>
    </div>
  );
};
