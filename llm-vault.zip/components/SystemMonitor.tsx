import React, { useState, useEffect } from 'react';
import { SafetyStatus } from '../types';

export const SystemMonitor: React.FC = () => {
  const [cpuLoad, setCpuLoad] = useState(24);
  const [memoryUsage, setMemoryUsage] = useState(41);
  const [networkTraffic, setNetworkTraffic] = useState(120); // req/min
  const [uptime, setUptime] = useState(0);

  // Simulate metrics changes
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuLoad(prev => Math.min(100, Math.max(10, prev + (Math.random() * 10 - 5))));
      setMemoryUsage(prev => Math.min(100, Math.max(20, prev + (Math.random() * 5 - 2))));
      setNetworkTraffic(prev => Math.max(0, Math.floor(prev + (Math.random() * 20 - 10))));
      setUptime(prev => prev + 1);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const isHttps = window.location.protocol === 'https:';
  
  const StatusIndicator = ({ label, status, icon }: { label: string, status: 'Active' | 'Inactive' | 'Verified', icon: string }) => (
    <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg bg-slate-700/50 flex items-center justify-center text-slate-400`}>
          <i className={`fas ${icon}`}></i>
        </div>
        <div>
          <div className="text-sm font-semibold text-slate-200">{label}</div>
          <div className="text-xs text-slate-500">Protection Layer</div>
        </div>
      </div>
      <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
        status === 'Inactive' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
      }`}>
        {status}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Resource Metrics */}
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-xs uppercase font-bold mb-2">CPU Load</div>
          <div className="flex items-end gap-2">
            <span className="text-2xl font-mono text-white">{cpuLoad.toFixed(1)}%</span>
            <div className="h-1.5 w-full bg-slate-700 rounded-full mb-1.5">
              <div className={`h-full rounded-full transition-all duration-500 ${cpuLoad > 80 ? 'bg-rose-500' : 'bg-indigo-500'}`} style={{ width: `${cpuLoad}%` }}></div>
            </div>
          </div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-xs uppercase font-bold mb-2">Memory</div>
          <div className="flex items-end gap-2">
            <span className="text-2xl font-mono text-white">{memoryUsage.toFixed(1)}%</span>
             <div className="h-1.5 w-full bg-slate-700 rounded-full mb-1.5">
              <div className={`h-full rounded-full transition-all duration-500 ${memoryUsage > 80 ? 'bg-amber-500' : 'bg-purple-500'}`} style={{ width: `${memoryUsage}%` }}></div>
            </div>
          </div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-xs uppercase font-bold mb-2">Net Traffic</div>
          <div className="text-2xl font-mono text-white">{networkTraffic} <span className="text-xs text-slate-500 font-sans">req/min</span></div>
          <div className="text-xs text-emerald-400 mt-1"><i className="fas fa-shield-alt"></i> DDoS Filter Active</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-xs uppercase font-bold mb-2">System Uptime</div>
          <div className="text-2xl font-mono text-white">{new Date(uptime * 1000).toISOString().substr(11, 8)}</div>
          <div className="text-xs text-slate-500 mt-1">Last Reboot: Just now</div>
        </div>
      </div>

      <h3 className="text-lg font-bold text-white mt-8 mb-4 flex items-center gap-2">
        <i className="fas fa-server text-indigo-400"></i> Hardware & Infrastructure Security
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <StatusIndicator label="Secure Boot / TPM" status="Verified" icon="fa-microchip" />
        <StatusIndicator label="OS Kernel Integrity" status="Verified" icon="fa-memory" />
        <StatusIndicator label="Filesystem Encryption" status="Active" icon="fa-file-code" />
        <StatusIndicator label="Supply Chain (SLSA-3)" status="Verified" icon="fa-cubes" />
      </div>

      <h3 className="text-lg font-bold text-white mt-8 mb-4 flex items-center gap-2">
        <i className="fas fa-network-wired text-indigo-400"></i> Network & Remote Access
      </h3>

      <div className="bg-slate-800/30 rounded-xl border border-slate-700 overflow-hidden">
        <table className="w-full text-sm text-left">
          <tbody className="divide-y divide-slate-700">
             <tr className="hover:bg-slate-800/50">
               <td className="p-4 text-slate-300"><i className="fas fa-globe mr-3 text-slate-500"></i>Connection Protocol</td>
               <td className="p-4 font-mono text-right">
                 {isHttps ? <span className="text-emerald-400"><i className="fas fa-lock mr-1"></i> HTTPS (TLS 1.3)</span> : <span className="text-amber-400"><i className="fas fa-unlock mr-1"></i> HTTP (Unsafe)</span>}
               </td>
             </tr>
             <tr className="hover:bg-slate-800/50">
               <td className="p-4 text-slate-300"><i className="fas fa-user-shield mr-3 text-slate-500"></i>IAM / Auth Provider</td>
               <td className="p-4 font-mono text-right text-slate-300">JWT (RS256) / MFA Enabled</td>
             </tr>
             <tr className="hover:bg-slate-800/50">
               <td className="p-4 text-slate-300"><i className="fas fa-filter mr-3 text-slate-500"></i>Firewall Rules</td>
               <td className="p-4 font-mono text-right text-emerald-400">Block All Inbound (Except 443)</td>
             </tr>
             <tr className="hover:bg-slate-800/50">
               <td className="p-4 text-slate-300"><i className="fas fa-bug mr-3 text-slate-500"></i>Intrusion Detection (IDS)</td>
               <td className="p-4 font-mono text-right text-emerald-400">Monitoring Active</td>
             </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
