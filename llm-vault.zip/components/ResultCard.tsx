import React from 'react';
import { SafetyStatus } from '../types';
import { MAILTO_LINK } from '../constants';

interface ResultCardProps {
  status: SafetyStatus;
  reason: string;
  confidence?: number;
  showHelpButton?: boolean;
}

export const ResultCard: React.FC<ResultCardProps> = ({ status, reason, confidence, showHelpButton }) => {
  let bgColor = "bg-emerald-950/30";
  let borderColor = "border-emerald-500/30";
  let iconColor = "text-emerald-400";
  let iconBg = "bg-emerald-500/10";
  let icon = "fa-check-circle";
  let titleColor = "text-emerald-300";
  let title = "Safe";

  if (status === SafetyStatus.WARNING) {
    bgColor = "bg-amber-950/30";
    borderColor = "border-amber-500/30";
    iconColor = "text-amber-400";
    iconBg = "bg-amber-500/10";
    icon = "fa-exclamation-triangle";
    titleColor = "text-amber-300";
    title = "Warning";
  } else if (status === SafetyStatus.DANGER) {
    bgColor = "bg-rose-950/30";
    borderColor = "border-rose-500/30";
    iconColor = "text-rose-400";
    iconBg = "bg-rose-500/10";
    icon = "fa-radiation";
    titleColor = "text-rose-300";
    title = "Danger Detected";
  }

  return (
    <div className={`mt-6 rounded-xl border ${borderColor} ${bgColor} backdrop-blur-md shadow-xl overflow-hidden transition-all duration-300 animate-fade-in`}>
      <div className="p-6">
        <div className="flex items-start gap-5">
          <div className={`p-3 rounded-xl ${iconBg} ${iconColor} shrink-0 flex items-center justify-center w-12 h-12`}>
             <i className={`fas ${icon} text-2xl`}></i>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
               <h3 className={`text-xl font-bold ${titleColor} tracking-tight`}>{title}</h3>
               {confidence !== undefined && (
                <span className={`text-[10px] uppercase font-bold px-2 py-1 rounded-full ${iconBg} ${iconColor} border border-${iconColor}/20 tracking-wider`}>
                  {(confidence * 100).toFixed(0)}% Confidence
                </span>
               )}
            </div>
            <p className="text-slate-200 text-lg leading-relaxed font-light">{reason}</p>
          </div>
        </div>
        
        {showHelpButton && (
          <div className="mt-6 pt-5 border-t border-slate-700/50 flex justify-end">
            <a 
              href={MAILTO_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-brand-purple to-purple-600 hover:from-purple-500 hover:to-brand-purple text-white font-semibold py-2.5 px-6 rounded-lg transition-all shadow-lg shadow-purple-900/30 transform hover:-translate-y-0.5 hover:shadow-purple-500/20"
            >
              <i className="fas fa-life-ring"></i>
              <span>Get Help Now</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};