import React, { useState } from 'react';
import { scanPrompt } from '../services/geminiService';
import { PromptScanResult, AuditLogEntry, SafetyStatus } from '../types';

interface Props {
  addAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

export const PromptFirewall: React.FC<Props> = ({ addAuditLog }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<PromptScanResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleScan = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await scanPrompt(input);
      setResult(res);
      addAuditLog({
        module: 'Input',
        action: 'Scan Prompt',
        status: res.safe ? SafetyStatus.SAFE : SafetyStatus.DANGER,
        details: res.safe ? 'Passed checks' : res.reason,
        hash: 'N/A' // Could hash the prompt if needed
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <i className="fas fa-dungeon text-indigo-400"></i> Input-Side Defense
        </h2>
        <p className="text-slate-400 text-sm mb-4">
          Protects against Prompt Injection, Jailbreaks, and Zero-width attacks.
          <br/>
          <span className="text-xs font-mono text-slate-500">Regex Block-list: (?i)(ignore|disregard|override|jonathan|dan|developer|mode)</span>
        </p>

        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-32 bg-slate-900 border border-slate-700 rounded-lg p-4 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono text-sm"
            placeholder="Enter user prompt to validate..."
          />
          <div className="absolute bottom-2 right-2 text-xs text-slate-600">
            {input.length} chars
          </div>
        </div>

        <button
          onClick={handleScan}
          disabled={loading || !input}
          className={`mt-4 w-full py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all ${
            loading ? 'bg-slate-700 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-900/20'
          }`}
        >
          {loading ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-shield-alt"></i>}
          Analyze Prompt
        </button>
      </div>

      {result && (
        <div className={`p-6 rounded-xl border ${result.safe ? 'bg-emerald-950/30 border-emerald-500/30' : 'bg-rose-950/30 border-rose-500/30'} backdrop-blur-sm animate-fade-in-up`}>
           <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${result.safe ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                <i className={`fas ${result.safe ? 'fa-check-shield' : 'fa-ban'} text-2xl`}></i>
              </div>
              <div className="flex-1">
                <h3 className={`text-lg font-bold mb-1 ${result.safe ? 'text-emerald-300' : 'text-rose-300'}`}>
                  {result.safe ? 'Prompt Allowed' : 'Prompt Blocked'}
                </h3>
                <p className="text-slate-300 text-sm mb-3">{result.reason}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                   <div className="bg-black/20 p-2 rounded">
                      <span className="text-slate-500 block">Injection Detected</span>
                      <span className="font-mono text-slate-200">{result.injection_detected ? 'YES' : 'NO'}</span>
                   </div>
                   <div className="bg-black/20 p-2 rounded">
                      <span className="text-slate-500 block">Semantic Safety Score</span>
                      <span className="font-mono text-slate-200">{result.semantic_score.toFixed(2)} / 1.0</span>
                   </div>
                   {result.flagged_terms.length > 0 && (
                      <div className="bg-black/20 p-2 rounded col-span-2">
                        <span className="text-slate-500 block">Flagged Terms</span>
                        <span className="font-mono text-rose-300">{result.flagged_terms.join(', ')}</span>
                      </div>
                   )}
                </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
